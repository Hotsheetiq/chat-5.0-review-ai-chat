﻿

namespace LCS.UI.API.QuickStart.Examples.Models
{
   public class UserAuthorizationModel
   {
      public string Username { get; set; }
      public string Password { get; set; }
      public int LocationID { get; set; }
   }
}
