﻿namespace LCS.UI.API.QuickStart.Examples.Models
{
   public class SelectListItemModel
   {
      public bool Selected { get; set; }
      public string Text { get; set; }
      public int ID { get; set; }
   }
}
