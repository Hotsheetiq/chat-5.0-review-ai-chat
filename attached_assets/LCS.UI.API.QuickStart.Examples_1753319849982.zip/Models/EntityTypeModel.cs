﻿namespace LCS.UI.API.QuickStart.Examples.Models
{
   public class EntityTypeModel
   {
      public int ColorEntityTypesID { get; set; }
      public int ColorID { get; set; }
      public int EntityType { get; set; }
   }
}